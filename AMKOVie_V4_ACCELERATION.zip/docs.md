# AMKOVie V4

Cette livraison avance simultanément le frontend PWA et le backend.

Fonctions visibles:
- tableau de bord
- suivi hydratation
- objectifs
- santé naturelle
- massage/bien-être
- professionnels
- assistant encadré
- profil

Fonctions backend:
- persistance SQLite de développement
- objectifs
- moteur SAFE
- schéma utilisateurs/plantes/professionnels

Production exige encore sécurité, authentification, base de données robuste, validation scientifique, conformité réglementaire, audit et packaging Android/iOS.
