# AMKOVie V4 — développement accéléré

## Voir l'application
Ouvrir `web/index.html`.

## Lancer l'API
cd api
pip install -r requirements.txt
uvicorn main:app --reload

## API
GET /health
POST /goals
POST /safe/evaluate

Prototype de développement : pas une certification médicale et pas une version store finale.
