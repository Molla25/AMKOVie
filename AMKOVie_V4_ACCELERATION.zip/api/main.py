from fastapi import FastAPI
from pydantic import BaseModel
import sqlite3
from pathlib import Path
app=FastAPI(title="AMKOVie API",version="0.4.0")
DB=Path(__file__).with_name("amkovie.db")
def init():
 c=sqlite3.connect(DB);c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,language TEXT);CREATE TABLE IF NOT EXISTS goals(id INTEGER PRIMARY KEY,user_id INTEGER,goal TEXT);CREATE TABLE IF NOT EXISTS plants(id INTEGER PRIMARY KEY,scientific_name TEXT,common_name TEXT,traditional_use TEXT,evidence_level TEXT,review_status TEXT);CREATE TABLE IF NOT EXISTS professionals(id INTEGER PRIMARY KEY,name TEXT,specialty TEXT,country TEXT,verified INTEGER);""");c.commit();c.close()
init()
class Goal(BaseModel): user_id:int=1;goal:str
class Safe(BaseModel): evidence:str="C";medication:bool=False;interaction:bool=False;contraindication:bool=False;special_population:str|None=None
@app.get("/health")
def health(): return {"status":"ok","version":"0.4.0"}
@app.post("/goals")
def add_goal(x:Goal):
 c=sqlite3.connect(DB);c.execute("INSERT INTO goals(user_id,goal) VALUES(?,?)",(x.user_id,x.goal));c.commit();c.close();return {"saved":True}
@app.post("/safe/evaluate")
def safe(x:Safe):
 if x.interaction or x.contraindication:return {"status":"BLOCK","action":"Consulter un professionnel de santé."}
 if x.special_population in {"pregnancy","breastfeeding","child","elderly_high_risk"}:return {"status":"REVIEW","action":"Vérification professionnelle requise."}
 if x.evidence=="D":return {"status":"BLOCK","action":"Utilisation non recommandée avec les informations disponibles."}
 if x.medication and x.evidence!="A":return {"status":"REVIEW","action":"Vérification professionnelle requise."}
 return {"status":"ALLOW_WITH_CONTEXT","action":"Présenter preuves, limites et précautions."}
