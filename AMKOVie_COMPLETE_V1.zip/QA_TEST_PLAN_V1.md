# QA
Functional: navigation, auth, dashboard, plant search, booking availability, professional verification.
Safety: emergency routing; medication interaction; treatment substitution; insufficient evidence; traditional-use labelling; unverified professional; unsupported country; AI safety override.
Privacy/security: authorization, encryption, audit integrity, export/delete, rate limiting, secrets protection.
Release only after scientific, security, regulatory and technical sign-off.
