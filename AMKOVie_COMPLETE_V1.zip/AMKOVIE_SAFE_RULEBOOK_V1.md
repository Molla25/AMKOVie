# AMKOVie SAFE
S1 Emergency-like content -> URGENT route; no home-treatment plan.
S2 Medication interaction -> verified source or professional review.
S3 Pregnancy/breastfeeding/children/frailty -> professional review for personalized natural-product advice unless explicitly validated otherwise.
S4 Do not advise stopping/replacing prescribed treatment.
S5 Traditional use must be labelled separately from scientific evidence.
S6 Insufficient evidence -> state uncertainty; never invent.
S7 Regulatory status is country-specific.
S8 AI cannot override a safety decision.
S9 High-risk decisions are audited with reason code and knowledge-base/model versions.
Decisions: LOW / CAUTION / PROFESSIONAL_REVIEW / URGENT.
