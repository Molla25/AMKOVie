# Plant record
## Identity
Scientific name; family; common names; local names; geographic/cultural context; parts used.
## Traditional use
Use; cultural context; preparation; label as TRADITIONAL USE.
## Evidence
Claim; evidence level; study type; population; limitations; source.
## Safety
Adverse effects; contraindications; interactions; pregnancy; breastfeeding; children; older/frail; chronic conditions; product quality.
## Regulatory
Country; category; status; source; last checked.
## Governance
Author; scientific reviewer; safety reviewer; approval status; version; review dates.
