# Roadmap
1 Foundation: repo, design system, auth, DB, consent, audit.
2 Health core: dashboard, goals, habits, notifications.
3 Natural health: plants, sources, evidence, review.
4 SAFE: risk engine, country rules, escalation.
5 AI: retrieval, sources, safety gate, human escalation.
6 Professionals: verification, profiles, services, availability, booking.
7 Privacy/security: consent center, export/delete, encryption, monitoring.
8 Beta: usability, safety red-team, accessibility, performance.
9 Production: jurisdiction, legal/privacy, store compliance, recovery, release.
