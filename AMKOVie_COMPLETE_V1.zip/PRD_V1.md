# AMKOVie PRD V1
## Modules
Account/consent, health dashboard, goals/habits, natural health, plants, AMKOVie SAFE, education, wellness/massage, professionals, booking, AI, notifications, privacy, professional portal, scientific/admin back office.
## Safety boundary
No autonomous diagnosis, prescribing, cure guarantees, treatment substitution or unsupported medical claims.
## Content lifecycle
Draft -> Scientific review -> Safety review -> Regulatory review where applicable -> Published -> Periodic review -> Archived.
## Release gates
Product usability -> scientific review -> safety/security -> jurisdictional review -> QA -> controlled beta -> production.
