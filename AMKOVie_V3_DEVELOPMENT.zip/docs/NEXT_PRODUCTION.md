# AMKOVie — étape de développement suivante

Livré dans V3:
- PWA installable (manifest + service worker)
- navigation et parcours principaux
- suivi hydratation local
- objectifs santé
- recherche de plantes de démonstration
- interface professionnels
- assistant avec garde-fou
- API FastAPI
- SQLite pour le développement
- tables users/goals/plants/professionals
- endpoint de seed
- test backend minimal

Avant publication réelle:
1. PostgreSQL/solution cloud sécurisée
2. authentification + MFA si nécessaire
3. chiffrement, journalisation, contrôle d'accès
4. consentements et politique de confidentialité juridiquement validés
5. base scientifique et interactions médicaments/plantes sous licence ou source autorisée
6. workflow de validation par experts
7. vérification des professionnels et autorisations par pays
8. analyse réglementaire (y compris qualification éventuelle de certaines fonctions comme dispositif médical)
9. audit cybersécurité
10. packaging Android/iOS, tests stores et publication.

Ce build est un environnement de développement et ne constitue pas une certification médicale.
