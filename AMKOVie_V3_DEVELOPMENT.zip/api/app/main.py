
import sqlite3
from pathlib import Path
from fastapi import FastAPI
from pydantic import BaseModel
DB=Path(__file__).parent.parent/'amkovie.db'
app=FastAPI(title='AMKOVie API',version='0.3.0')
def init():
    c=sqlite3.connect(DB); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, language TEXT DEFAULT 'fr');
    CREATE TABLE IF NOT EXISTS goals(id INTEGER PRIMARY KEY, user_id INTEGER, goal TEXT);
    CREATE TABLE IF NOT EXISTS plants(id INTEGER PRIMARY KEY, scientific_name TEXT, common_name TEXT, traditional_use TEXT, evidence_level TEXT, review_status TEXT);
    CREATE TABLE IF NOT EXISTS professionals(id INTEGER PRIMARY KEY, name TEXT, specialty TEXT, country TEXT, verified INTEGER DEFAULT 0);
    '''); c.commit(); c.close()
init()
class Goal(BaseModel): user_id:int=1; goal:str
class Safety(BaseModel): evidence:str='C'; medication:bool=False; interaction:bool=False; contraindication:bool=False; special_population:str|None=None
@app.get('/health')
def health(): return {'status':'ok','service':'AMKOVie','version':'0.3.0'}
@app.post('/goals')
def goal(x:Goal):
    c=sqlite3.connect(DB); c.execute('INSERT INTO goals(user_id,goal) VALUES(?,?)',(x.user_id,x.goal)); c.commit(); c.close(); return {'saved':True}
@app.get('/plants')
def plants():
    c=sqlite3.connect(DB); rows=c.execute('SELECT id,scientific_name,common_name,traditional_use,evidence_level,review_status FROM plants').fetchall(); c.close()
    return [{'id':r[0],'scientific_name':r[1],'common_name':r[2],'traditional_use':r[3],'evidence_level':r[4],'review_status':r[5]} for r in rows]
@app.post('/seed/demo')
def seed():
    c=sqlite3.connect(DB); c.execute("INSERT INTO plants(scientific_name,common_name,traditional_use,evidence_level,review_status) VALUES(?,?,?,?,?)",('Moringa oleifera','Moringa','Usage traditionnel à documenter','C','REVIEW_REQUIRED')); c.commit(); c.close(); return {'seeded':True}
