
from app.main import app
def test_import(): assert app.title=="AMKOVie API"
