# AMKOVie V3 DEVELOPMENT

## Frontend
Ouvrir `web/index.html`. Le service worker permet une base PWA.

## API
`cd api`
`pip install -r requirements.txt`
`uvicorn app.main:app --reload`

## Base
SQLite de développement dans `api/amkovie.db`.

## Tests
`pytest`

## Important
Prototype de développement, non certifié comme dispositif médical.
