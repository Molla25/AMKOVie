from app.safety import evaluate_recommendation

def test_interaction_blocks():
    r = evaluate_recommendation(evidence="A", interaction=True)
    assert r.status == "BLOCK"

def test_pregnancy_requires_review():
    r = evaluate_recommendation(evidence="B", special_population="pregnancy")
    assert r.status == "REVIEW"

def test_traditional_use_is_contextual():
    r = evaluate_recommendation(evidence="C")
    assert r.status == "ALLOW_WITH_CONTEXT"

def test_insufficient_evidence_blocks():
    r = evaluate_recommendation(evidence="D")
    assert r.status == "BLOCK"
