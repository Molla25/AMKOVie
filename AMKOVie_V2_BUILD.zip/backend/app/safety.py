from dataclasses import dataclass
from typing import List

@dataclass
class SafetyResult:
    status: str
    reasons: List[str]
    action: str

HIGH_RISK = {"pregnancy", "breastfeeding", "child", "severe_allergy", "anticoagulant"}

def evaluate_recommendation(*, evidence: str, medication: bool=False,
                            interaction: bool=False, contraindication: bool=False,
                            special_population: str|None=None) -> SafetyResult:
    reasons = []
    if interaction:
        reasons.append("interaction_medicamenteuse_possible")
    if contraindication:
        reasons.append("contre_indication_connue")
    if special_population in HIGH_RISK:
        reasons.append("population_particuliere")
    if evidence not in {"A", "B"}:
        reasons.append("preuves_limitees_ou_usage_traditionnel")
    if medication:
        reasons.append("traitement_en_cours")

    if interaction or contraindication:
        return SafetyResult("BLOCK", reasons, "Consulter un professionnel de santé avant toute utilisation.")
    if special_population in HIGH_RISK or (medication and evidence not in {"A"}):
        return SafetyResult("REVIEW", reasons, "Une vérification par un professionnel de santé est requise.")
    if evidence == "D":
        return SafetyResult("BLOCK", reasons, "AMKOVie ne recommande pas cette utilisation.")
    return SafetyResult("ALLOW_WITH_CONTEXT", reasons, "Présenter les preuves, limites et précautions.")

def plant_card(name: str, evidence: str, traditional_use: str) -> dict:
    return {
        "name": name,
        "evidence_level": evidence,
        "traditional_use": traditional_use,
        "medical_claim": False,
        "safety_review_required": True
    }
