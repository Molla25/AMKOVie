from fastapi import FastAPI
from pydantic import BaseModel
from .safety import evaluate_recommendation, plant_card

app = FastAPI(title="AMKOVie API", version="0.2.0")

class SafetyRequest(BaseModel):
    evidence: str = "C"
    medication: bool = False
    interaction: bool = False
    contraindication: bool = False
    special_population: str|None = None

@app.get("/health")
def health():
    return {"status":"ok","service":"AMKOVie API","version":"0.2.0"}

@app.post("/safety/evaluate")
def safety(req: SafetyRequest):
    return evaluate_recommendation(**req.model_dump()).__dict__

@app.get("/plants/demo")
def plants():
    return [plant_card("Moringa oleifera", "C",
        "Exemple de fiche pédagogique : les usages traditionnels doivent être distingués des preuves scientifiques.")]
