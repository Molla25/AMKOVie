# AMKOVie API — V0.2
Prototype backend for the health-information platform.

## Run
pip install -r requirements.txt
uvicorn app.main:app --reload

## Endpoints
GET /health
GET /plants/demo
POST /safety/evaluate

This is a development scaffold, not a certified medical device or clinical decision system.
