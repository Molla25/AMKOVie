# AMKOVie Safety Policy V0.2

1. Ne jamais transformer un usage traditionnel en preuve d'efficacité.
2. Ne jamais promettre une guérison.
3. Ne jamais conseiller d'arrêter/modifier un traitement prescrit.
4. Une interaction ou contre-indication connue déclenche BLOCK.
5. Une population à risque ou un traitement en cours peut déclencher REVIEW.
6. Les preuves insuffisantes ne doivent pas devenir une recommandation.
7. Les situations urgentes doivent être orientées vers des soins appropriés.
8. Toute recommandation clinique personnalisée doit passer par une gouvernance adaptée.

Les principes suivent l'orientation générale de l'OMS sur l'intégration sûre, efficace et fondée sur les données probantes des approches traditionnelles, complémentaires et intégratives, ainsi que ses recommandations de gouvernance éthique de l'IA en santé.
