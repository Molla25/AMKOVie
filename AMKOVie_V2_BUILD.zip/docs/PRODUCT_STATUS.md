# État réel du projet

CONSTRUIT MAINTENANT:
- interface mobile V2 fonctionnelle (prototype)
- API FastAPI
- endpoint de santé
- moteur AMKOVie SAFE V0.2
- tests unitaires du moteur SAFE
- fiche plante de démonstration
- Dockerfile backend
- architecture et README

À FAIRE AVANT PRODUCTION:
- vraie base de données
- authentification sécurisée
- chiffrement/gestion des données de santé
- gestion des consentements
- système de professionnels vérifiés
- moteur d'interactions médicamenteuses alimenté par une source fiable/licenciée
- comité scientifique et processus de revue
- conformité juridique par pays
- tests sécurité/pénétration
- audit clinique et réglementaire
- publication stores.

Ce build est un socle logiciel de développement, pas un dispositif médical certifié.
