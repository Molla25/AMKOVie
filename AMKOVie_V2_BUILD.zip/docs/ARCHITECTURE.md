# AMKOVie — Architecture V2

Utilisateur → Interface mobile → API → moteur de sécurité → base de connaissances validée → réponse contextualisée.

Principes:
- séparation usages traditionnels / preuves scientifiques
- journalisation des versions de contenu
- revue humaine pour les contenus à risque
- consentement et minimisation des données
- IA d'assistance, sans diagnostic autonome ni prescription
- orientation vers un professionnel lorsque les règles de sécurité l'exigent
