# AMKOVie V2 — Build concret

Ce dépôt contient une première tranche réellement exécutable:
- frontend mobile PWA de démonstration
- API FastAPI
- moteur AMKOVie SAFE
- tests
- Docker
- documentation d'architecture et de sécurité

## Démarrage backend
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload

## Tests
cd backend
pytest

## Frontend
Ouvrir frontend/index.html dans un navigateur.

## Statut
Prototype de développement. Pas de certification médicale, pas de validation clinique, pas de mise en production.
