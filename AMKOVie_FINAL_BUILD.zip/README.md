# AMKOVie FINAL BUILD

Ouvrir `app/index.html` pour voir le prototype.

Backend: `cd backend && pip install -r requirements.txt && uvicorn app.main:app --reload`

Tests: `cd backend && pytest`
