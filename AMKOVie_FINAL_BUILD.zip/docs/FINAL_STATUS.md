# AMKOVie — état du build

Cette version assemble un prototype mobile cohérent et un backend minimal testable.

Inclus:
- interface mobile
- navigation principale
- santé personnelle
- santé naturelle
- massage/bien-être
- annuaire professionnel (interface)
- assistant IA (interface encadrée)
- profil/confidentialité
- API FastAPI
- moteur SAFE
- tests automatisés

Reste indispensable avant une vraie mise en production:
- base de données sécurisée
- authentification et gestion des sessions
- chiffrement et gouvernance des données de santé
- sources scientifiques/licences
- base d'interactions médicaments-plantes validée
- validation scientifique humaine
- vérification des professionnels
- conformité réglementaire pays par pays
- audit sécurité
- politique de confidentialité et consentements juridiques
- tests de charge et tests mobiles
- packaging Android/iOS et comptes développeur

Le build est un logiciel prototype de développement et ne doit pas être utilisé comme dispositif médical.
