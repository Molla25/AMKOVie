from app.safety import evaluate

def test_block(): assert evaluate(interaction=True).status=='BLOCK'
def test_review(): assert evaluate(special_population='pregnancy').status=='REVIEW'
def test_allow(): assert evaluate(evidence='A').status=='ALLOW_WITH_CONTEXT'
def test_insufficient(): assert evaluate(evidence='D').status=='BLOCK'
