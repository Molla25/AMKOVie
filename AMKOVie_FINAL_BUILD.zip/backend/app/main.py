from fastapi import FastAPI
from pydantic import BaseModel
from .safety import evaluate
app=FastAPI(title="AMKOVie API",version="1.0.0")
class Req(BaseModel):
    evidence:str="C"; medication:bool=False; interaction:bool=False; contraindication:bool=False; special_population:str|None=None
@app.get("/health")
def health(): return {"status":"ok","app":"AMKOVie","version":"1.0.0"}
@app.post("/safe/evaluate")
def safe(r:Req): return evaluate(**r.model_dump()).__dict__
