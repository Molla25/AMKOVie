from dataclasses import dataclass
@dataclass
class Result:
    status:str
    message:str
def evaluate(evidence="C", medication=False, interaction=False, contraindication=False, special_population=None):
    if interaction or contraindication:
        return Result("BLOCK","Consultation d'un professionnel de santé requise.")
    if special_population in {"pregnancy","breastfeeding","child","elderly_high_risk"}:
        return Result("REVIEW","Vérification professionnelle requise.")
    if evidence=="D":
        return Result("BLOCK","AMKOVie ne recommande pas cette utilisation avec les informations disponibles.")
    if medication and evidence!="A":
        return Result("REVIEW","Traitement en cours : vérification professionnelle requise.")
    return Result("ALLOW_WITH_CONTEXT","Présenter preuves, limites et précautions.")
