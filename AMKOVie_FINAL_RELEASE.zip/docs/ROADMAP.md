# Roadmap
V6 : socle complet fonctionnel.
V7 : authentification JWT/refresh, rôles, PostgreSQL, audit, notifications, calendrier de disponibilité.
V8 : réservation complète, paiement selon pays, messagerie sécurisée.
V9 : contenus scientifiques enrichis, comité de validation, analytics.
V10 : publication Android/iOS et déploiement cloud après audits.
