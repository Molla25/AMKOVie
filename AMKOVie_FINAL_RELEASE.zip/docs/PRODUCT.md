# Produit

AMKOVie est structuré autour de 8 espaces : Ma santé, Santé naturelle, Nutrition, Bien-être, Éducation santé, Professionnels, Assistant et Profil.

## Règle éditoriale
Une fiche de santé naturelle doit distinguer :
- usage traditionnel ;
- données scientifiques ;
- niveau de preuve ;
- risques et effets indésirables ;
- contre-indications ;
- interactions ;
- populations particulières ;
- signaux d'orientation vers un professionnel ;
- sources et date de revue.

La stratégie OMS 2025–2034 pour la médecine traditionnelle met notamment l'accent sur les preuves, la sécurité, la réglementation et l'intégration appropriée dans les systèmes de santé. citeturn0search1turn0search0
