# Écrans AMKOVie

1. Splash / identité
2. Bienvenue
3. Inscription / connexion
4. Consentements
5. Profil santé
6. Tableau de bord
7. Objectifs
8. Hydratation
9. Sommeil
10. Activité
11. Nutrition
12. Santé naturelle
13. Fiche plante
14. Vérification sécurité
15. Éducation santé
16. Bien-être
17. Massage
18. Recherche professionnel
19. Profil professionnel
20. Disponibilités
21. Réservation
22. Mes rendez-vous
23. Assistant AMKOVie
24. Historique assistant
25. Notifications
26. Paramètres
27. Confidentialité
28. Aide
29. Administration
30. Validation scientifique
