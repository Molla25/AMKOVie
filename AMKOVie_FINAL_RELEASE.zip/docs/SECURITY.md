# Sécurité et santé

## Assistant
- Pas de diagnostic autonome.
- Pas de prescription.
- Pas d'instruction pour arrêter ou modifier un traitement prescrit.
- Escalade vers un professionnel en cas de risque.
- Journalisation des décisions de sécurité côté serveur.

## Données
Avant production :
- chiffrement en transit et au repos ;
- contrôle d'accès par rôle ;
- gestion de sessions/tokens sécurisés ;
- sauvegardes ;
- journal d'audit ;
- minimisation des données ;
- suppression/export selon le droit applicable ;
- tests d'intrusion.

L'OMS recommande que l'IA en santé soit conçue et déployée avec des garanties éthiques, de gouvernance et de responsabilité. citeturn0search3turn0search6
