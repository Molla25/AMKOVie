# AMKOVie — passage en production

## Architecture cible
- Mobile: Flutter ou React Native
- Web/admin: React/Next.js
- API: FastAPI
- DB: PostgreSQL
- Cache/queues: Redis
- Fichiers: stockage objet chiffré
- Observabilité: logs, métriques, alertes
- Sécrets: gestionnaire de secrets
- CI/CD: tests → sécurité → staging → production

## Sécurité
- OAuth2/OIDC ou JWT avec rotation de refresh tokens
- RBAC: utilisateur, professionnel, validateur, administrateur
- MFA pour les comptes privilégiés
- chiffrement TLS
- chiffrement des données sensibles au repos
- journal d'audit
- rate limiting
- sauvegardes et restauration testée
- tests SAST/DAST et pentest avant lancement

## Santé
Les fonctions cliniques doivent faire l'objet d'une analyse réglementaire pays par pays. Les contenus de santé naturelle doivent distinguer usage traditionnel, données probantes, risques et interactions. La stratégie OMS 2025–2034 met l'accent sur preuves, sécurité, réglementation et intégration appropriée. 
