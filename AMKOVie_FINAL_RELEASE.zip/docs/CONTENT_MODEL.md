# Modèle de contenu santé naturelle

Chaque contenu doit posséder : titre, noms locaux, nom scientifique, partie utilisée, description, usage traditionnel, préparation, indications étudiées, niveau de preuve, risques, contre-indications, interactions, populations particulières, orientation professionnelle, sources, date de revue, auteur, validateur et statut.

Statuts : DRAFT → REVIEW → APPROVED / REJECTED.

Aucun contenu non approuvé ne doit être présenté comme conseil clinique.
