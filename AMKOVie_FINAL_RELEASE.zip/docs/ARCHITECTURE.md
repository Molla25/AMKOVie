# Architecture V6
Frontend PWA → API FastAPI → SQLite development database.
Production target: PostgreSQL, object storage, Redis/job queue, managed secrets, observability, CDN, WAF and separate admin portal.
