# AMKOVie — Final Release Package

Socle complet de développement et de pré-production.

Inclus : PWA mobile, API FastAPI, comptes, objectifs, hydratation, bibliothèque santé naturelle, moteur AMKOVie SAFE, professionnels, rendez-vous, consentements, assistant avec garde-fous, administration, validation éditoriale, Docker et documentation.

Avant publication réelle : infrastructure sécurisée, PostgreSQL, authentification robuste, gestion des secrets, chiffrement, sauvegardes, monitoring, contrôle d'accès, tests de sécurité, revue clinique et validation réglementaire pays par pays.

Pour la santé naturelle, les contenus doivent distinguer usages traditionnels, preuves, risques et interactions. L'OMS met actuellement l'accent sur les preuves, la sécurité, la réglementation et l'intégration appropriée des médecines traditionnelles/complementaires. 
