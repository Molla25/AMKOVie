# AMKOVie — Complete Application V6

Application de santé numérique et bien-être, conçue comme une base de production.

## Modules
- Tableau de bord santé
- Objectifs, hydratation, sommeil et activité
- Bibliothèque santé naturelle avec niveau de preuve et sécurité
- Bien-être / massage
- Professionnels et prise de rendez-vous
- Assistant AMKOVie avec garde-fous
- Profil, consentements et confidentialité
- Administration et validation éditoriale
- API FastAPI + SQLite
- PWA installable

## Démarrage local

```bash
cd api
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Puis ouvrir `web/index.html` ou servir le dossier `web/`.

## Important
Cette version est un socle logiciel fonctionnel de développement. Elle n'est pas une certification médicale, réglementaire ou de sécurité. Avant une mise en production réelle : revue clinique, juridique, cybersécurité, protection des données, validation des contenus et tests de sécurité doivent être réalisés.

La logique de contenu naturel distingue les usages traditionnels, les données scientifiques et les précautions. L'IA ne doit pas diagnostiquer, prescrire ni remplacer un professionnel.
