import os, tempfile
os.environ["AMKOVIE_DB"]=os.path.join(tempfile.gettempdir(),"amkovie_test.sqlite")
from main import safe

def test_block_interaction():
    r=safe(type("X",(),{"contraindication":False,"interaction":True,"special_population":None,"evidence":"A","medication":False})())
    assert r["decision"]=="BLOCK"

def test_review_medication():
    r=safe(type("X",(),{"contraindication":False,"interaction":False,"special_population":None,"evidence":"B","medication":True})())
    assert r["decision"]=="REVIEW"
