from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
import sqlite3, hashlib, secrets, datetime, os

DB = os.getenv("AMKOVIE_DB", "amkovie.db")
app = FastAPI(title="AMKOVie API", version="6.0.0")

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    c=db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS goals(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL,
      target TEXT, progress INTEGER DEFAULT 0, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS hydration(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, ml INTEGER NOT NULL,
      recorded_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS plants(
      id INTEGER PRIMARY KEY AUTOINCREMENT, common_name TEXT NOT NULL, scientific_name TEXT,
      traditional_use TEXT, evidence TEXT, safety TEXT, interactions TEXT,
      status TEXT DEFAULT 'REVIEW', updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS professionals(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, specialty TEXT NOT NULL,
      country TEXT, city TEXT, verified INTEGER DEFAULT 0, active INTEGER DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS appointments(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, professional_id INTEGER NOT NULL,
      starts_at TEXT NOT NULL, reason TEXT, status TEXT DEFAULT 'REQUESTED', created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS consents(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, kind TEXT NOT NULL,
      accepted INTEGER NOT NULL, version TEXT NOT NULL, accepted_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS content_reviews(
      id INTEGER PRIMARY KEY AUTOINCREMENT, content_type TEXT NOT NULL, content_id INTEGER NOT NULL,
      status TEXT NOT NULL, reviewer TEXT, notes TEXT, reviewed_at TEXT NOT NULL
    );
    """)
    if not c.execute("SELECT 1 FROM plants LIMIT 1").fetchone():
        now=datetime.datetime.utcnow().isoformat()
        c.executemany("""INSERT INTO plants(common_name,scientific_name,traditional_use,evidence,safety,interactions,status,updated_at)
        VALUES(?,?,?,?,?,?,?,?)""", [
            ("Gingembre","Zingiber officinale","Usage traditionnel dans diverses préparations alimentaires et de bien-être.",
             "Données variables selon l'usage et la formulation; évaluation spécifique requise.",
             "Peut présenter des effets indésirables et des précautions selon la personne.",
             "Vérifier les médicaments et situations particulières avant usage.","REVIEW",now),
            ("Hibiscus","Hibiscus sabdariffa","Infusion traditionnellement consommée comme boisson.",
             "Données humaines disponibles mais dépendantes de l'indication et de la préparation.",
             "La sécurité doit être évaluée selon la dose, la personne et les traitements.",
             "Vérifier les traitements et les situations particulières.","REVIEW",now)
        ])
    if not c.execute("SELECT 1 FROM professionals LIMIT 1").fetchone():
        c.executemany("""INSERT INTO professionals(name,specialty,country,city,verified)
        VALUES(?,?,?,?,?)""", [
            ("Dr Exemple Santé","Médecine générale","Togo","Lomé",0),
            ("Praticien Bien-être Démo","Massage bien-être","Togo","Lomé",0)
        ])
    c.commit(); c.close()

init()

def now(): return datetime.datetime.utcnow().isoformat()
def pwd(x): return hashlib.sha256(x.encode()).hexdigest()

class Register(BaseModel):
    name: str = Field(min_length=2)
    email: str
    password: str = Field(min_length=6)

class GoalIn(BaseModel):
    title: str
    target: Optional[str] = None

class HydrationIn(BaseModel):
    ml: int = Field(gt=0, le=5000)

class AppointmentIn(BaseModel):
    user_id: int
    professional_id: int
    starts_at: str
    reason: Optional[str]=None

class ConsentIn(BaseModel):
    user_id: int
    kind: str
    accepted: bool
    version: str="1.0"

class SafeInput(BaseModel):
    medication: bool=False
    interaction: bool=False
    contraindication: bool=False
    special_population: Optional[str]=None
    evidence: str="B"

@app.get("/health")
def health(): return {"status":"ok","app":"AMKOVie","version":"6.0.0"}

@app.post("/auth/register")
def register(x:Register):
    c=db()
    try:
        cur=c.execute("INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",
                      (x.name,x.email.lower().strip(),pwd(x.password),now()))
        c.commit()
        return {"id":cur.lastrowid,"name":x.name,"email":x.email.lower().strip()}
    except sqlite3.IntegrityError:
        raise HTTPException(409,"Email déjà utilisé")
    finally: c.close()

@app.post("/auth/login")
def login(x:Register):
    c=db()
    row=c.execute("SELECT id,name,email FROM users WHERE email=? AND password_hash=?",
                  (x.email.lower().strip(),pwd(x.password))).fetchone()
    c.close()
    if not row: raise HTTPException(401,"Identifiants invalides")
    return dict(row)

@app.get("/dashboard/{user_id}")
def dashboard(user_id:int):
    c=db()
    goals=[dict(r) for r in c.execute("SELECT * FROM goals WHERE user_id=? ORDER BY id DESC",(user_id,))]
    hydration=sum(r["ml"] for r in c.execute(
        "SELECT ml FROM hydration WHERE user_id=? AND recorded_at LIKE ?",
        (user_id,datetime.datetime.utcnow().date().isoformat()+"%")))
    c.close()
    return {"hydration_ml":hydration,"hydration_target_ml":2000,"goals":goals}

@app.post("/goals/{user_id}")
def add_goal(user_id:int,x:GoalIn):
    c=db(); cur=c.execute("INSERT INTO goals(user_id,title,target,created_at) VALUES(?,?,?,?)",
                          (user_id,x.title,x.target,now())); c.commit(); out={"id":cur.lastrowid,**x.model_dump(),"progress":0}; c.close(); return out

@app.post("/hydration/{user_id}")
def add_hydration(user_id:int,x:HydrationIn):
    c=db(); c.execute("INSERT INTO hydration(user_id,ml,recorded_at) VALUES(?,?,?)",(user_id,x.ml,now())); c.commit(); c.close(); return {"ok":True,"added_ml":x.ml}

@app.get("/plants")
def plants(q:Optional[str]=None):
    c=db()
    if q:
        rows=c.execute("SELECT * FROM plants WHERE common_name LIKE ? OR scientific_name LIKE ? ORDER BY common_name",
                       (f"%{q}%",f"%{q}%"))
    else: rows=c.execute("SELECT * FROM plants ORDER BY common_name")
    out=[dict(r) for r in rows]; c.close(); return out

@app.get("/professionals")
def professionals(country:Optional[str]=None):
    c=db()
    rows=c.execute("SELECT * FROM professionals WHERE active=1 AND (? IS NULL OR country=?)",
                   (country,country)).fetchall()
    out=[dict(r) for r in rows]; c.close(); return out

@app.post("/appointments")
def appointment(x:AppointmentIn):
    c=db()
    if not c.execute("SELECT 1 FROM professionals WHERE id=? AND active=1",(x.professional_id,)).fetchone():
        c.close(); raise HTTPException(404,"Professionnel indisponible")
    cur=c.execute("""INSERT INTO appointments(user_id,professional_id,starts_at,reason,status,created_at)
                     VALUES(?,?,?,?,?,?)""",(x.user_id,x.professional_id,x.starts_at,x.reason,"REQUESTED",now()))
    c.commit(); c.close(); return {"id":cur.lastrowid,"status":"REQUESTED"}

@app.post("/consents")
def consent(x:ConsentIn):
    c=db(); cur=c.execute("""INSERT INTO consents(user_id,kind,accepted,version,accepted_at)
                             VALUES(?,?,?,?,?)""",(x.user_id,x.kind,int(x.accepted),x.version,now()))
    c.commit(); c.close(); return {"id":cur.lastrowid,"accepted":x.accepted}

@app.post("/safe/evaluate")
def safe(x:SafeInput):
    reasons=[]
    if x.contraindication: return {"decision":"BLOCK","reasons":["Contre-indication déclarée. Avis professionnel requis."]}
    if x.interaction: return {"decision":"BLOCK","reasons":["Interaction potentielle. Avis professionnel requis."]}
    if x.special_population in {"pregnancy","breastfeeding","child","elderly_high_risk"}:
        reasons.append("Population particulière : validation professionnelle recommandée.")
        return {"decision":"REVIEW","reasons":reasons}
    if x.evidence=="D": return {"decision":"BLOCK","reasons":["Niveau de preuve insuffisant ou risque préoccupant."]}
    if x.medication and x.evidence!="A":
        return {"decision":"REVIEW","reasons":["Traitement en cours + données insuffisantes pour un conseil autonome."]}
    return {"decision":"ALLOW_WITH_CONTEXT","reasons":["Présenter les limites des preuves et les précautions."]}

@app.get("/admin/content")
def admin_content():
    c=db()
    rows=c.execute("""SELECT p.id,p.common_name,p.scientific_name,p.status,p.updated_at,
                      (SELECT status FROM content_reviews r WHERE r.content_id=p.id AND r.content_type='plant'
                       ORDER BY r.id DESC LIMIT 1) last_review
                      FROM plants p ORDER BY p.id DESC""").fetchall()
    out=[dict(r) for r in rows]; c.close(); return out

@app.post("/admin/content/{plant_id}/review")
def review(plant_id:int,status:str,reviewer:str="admin",notes:str=""):
    allowed={"DRAFT","REVIEW","APPROVED","REJECTED"}
    if status not in allowed: raise HTTPException(400,"Statut invalide")
    c=db()
    if not c.execute("SELECT 1 FROM plants WHERE id=?",(plant_id,)).fetchone():
        c.close(); raise HTTPException(404,"Contenu introuvable")
    c.execute("UPDATE plants SET status=?,updated_at=? WHERE id=?",(status,now(),plant_id))
    c.execute("""INSERT INTO content_reviews(content_type,content_id,status,reviewer,notes,reviewed_at)
                 VALUES('plant',?,?,?,?,?)""",(plant_id,status,reviewer,notes,now()))
    c.commit(); c.close(); return {"ok":True,"status":status}
