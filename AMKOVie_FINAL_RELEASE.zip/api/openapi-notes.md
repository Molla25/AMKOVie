# API V7 — groupes

/auth — inscription, connexion, sessions
/users — profil
/health — mesures et objectifs
/natural — plantes, contenus, sécurité
/wellness — services et praticiens
/professionals — profils et vérification
/appointments — disponibilités et réservations
/assistant — conversations avec garde-fous
/consents — consentements et versions
/admin — validation, audit, utilisateurs, contenus
/notifications — événements et rappels
